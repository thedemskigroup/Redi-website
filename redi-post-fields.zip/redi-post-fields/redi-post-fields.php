<?php
/**
 * Plugin Name:       REDI Post Fields
 * Description:       Adds the post fields the REDI Astro frontend expects but REDI Headless CMS does not map — authorName, externalUrl, source and heroImage — as editable ACF fields, includes them in the REST output, and stops WordPress rewriting punctuation in API responses. Additive and reversible; deactivating restores the previous behaviour exactly.
 * Version:           1.3.0
 * Author:            Ethixweb
 * Requires at least: 6.0
 * Requires PHP:      7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Why this exists
 * ---------------
 * REDI Headless CMS maps a post to { id, slug, title, excerpt, contentHtml,
 * date, author, tags, featuredImage }. The frontend's BlogPost type also has
 * three optional fields that mapping omits:
 *
 *   authorName   the byline the frontend shows, e.g. "REDI Sites Team" or
 *                "Libsyn" — these are source attributions, not WordPress
 *                users, so the post author cannot supply them
 *   externalUrl  a post that links straight out to third-party coverage
 *   source       { name, url } for the outbound "read the source" link
 *   heroImage    wider crop at the top of the article, falls back to featuredImage
 *
 * Six of the ten REDI news posts are external links. Without externalUrl they
 * render as internal articles with no article behind them, so those posts
 * cannot be published to WordPress until this exists.
 *
 * Nothing here edits REDI Headless CMS. The fields are registered separately
 * and added to the REST response after that plugin has built it, so the two
 * stay independent and removing this one simply removes the three fields.
 */

// ---------------------------------------------------------------------------
// 1. Register the fields (editable in wp-admin, and writable over REST).
// ---------------------------------------------------------------------------
add_action(
	'acf/init',
	function () {
		if ( ! function_exists( 'acf_add_local_field_group' ) ) {
			return; // ACF inactive — fail quiet rather than fatal.
		}

		acf_add_local_field_group(
			array(
				'key'                   => 'group_redi_post_fields',
				'title'                 => 'Post Details (REDI)',
				'menu_order'            => 20,
				'position'              => 'normal',
				'active'                => true,
				// Without this the REST API accepts `acf` but declares no writable
				// properties, which is what blocked the content import.
				'show_in_rest'          => 1,
				'location'              => array(
					array(
						array(
							'param'    => 'post_type',
							'operator' => '==',
							'value'    => 'post',
						),
					),
				),
				'fields'                => array(
					array(
						'key'          => 'field_redi_author_name',
						'label'        => 'Author / Byline',
						'name'         => 'authorName',
						'type'         => 'text',
						'instructions' => 'Shown as the byline on the card, the article page and in the RSS feed. Leave empty to fall back to the WordPress post author.',
					),
					array(
						'key'          => 'field_redi_external_url',
						'label'        => 'External URL',
						'name'         => 'externalUrl',
						'type'         => 'url',
						'instructions' => 'Optional. If set, the card links straight to this URL in a new tab and no article page is generated for this post.',
					),
					array(
						'key'          => 'field_redi_source',
						'label'        => 'Source',
						'name'         => 'source',
						'type'         => 'group',
						'instructions' => 'Optional. External coverage this post reports on; renders a "read the source" link.',
						'layout'       => 'block',
						'sub_fields'   => array(
							array(
								'key'   => 'field_redi_source_name',
								'label' => 'Source name',
								'name'  => 'name',
								'type'  => 'text',
							),
							array(
								'key'   => 'field_redi_source_url',
								'label' => 'Source URL',
								'name'  => 'url',
								'type'  => 'url',
							),
						),
					),
					array(
						'key'           => 'field_redi_hero_image',
						'label'         => 'Hero Image',
						'name'          => 'heroImage',
						'type'          => 'image',
						'instructions'  => 'Optional. Wider crop shown at the top of the article page. Falls back to the featured image when empty.',
						'return_format' => 'array',
						'preview_size'  => 'medium',
					),
				),
			)
		);
	}
);

// ---------------------------------------------------------------------------
// 2. Add them to the REST output for posts.
// ---------------------------------------------------------------------------

/** Shapes an ACF image value into the frontend's WPImage, or null when unset. */
if ( ! function_exists( 'redi_post_fields_image' ) ) :
function redi_post_fields_image( $value ) {
	if ( is_array( $value ) && ! empty( $value['url'] ) ) {
		return array(
			'url'    => $value['url'],
			'alt'    => isset( $value['alt'] ) ? (string) $value['alt'] : '',
			'width'  => isset( $value['width'] ) ? $value['width'] : null,
			'height' => isset( $value['height'] ) ? $value['height'] : null,
		);
	}

	// A field written over REST stores an attachment id rather than an array.
	if ( is_numeric( $value ) && (int) $value > 0 ) {
		$id  = (int) $value;
		$url = wp_get_attachment_url( $id );
		if ( $url ) {
			return array(
				'url'    => $url,
				'alt'    => (string) get_post_meta( $id, '_wp_attachment_image_alt', true ),
				'width'  => null,
				'height' => null,
			);
		}
	}

	return null;
}

endif;

/**
 * Runs at priority 99 so it lands after REDI Headless CMS has replaced the
 * response with the frontend's shape — at a lower priority these keys would
 * be built and then thrown away.
 */
add_filter(
	'rest_prepare_post',
	function ( $response, $post, $request ) {
		if ( ! function_exists( 'get_field' ) || ! ( $response instanceof WP_REST_Response ) ) {
			return $response;
		}

		/*
		 * Frontend requests only.
		 *
		 * wp-admin and the block editor ask these routes for `context=edit`
		 * and need WordPress's own shape back. This filter writes the
		 * frontend's shape: it replaces `author` (an integer user ID in core)
		 * with { name }, and adds keys core does not declare. Doing that to an
		 * edit response corrupts the record the editor is holding - the author
		 * control reads an object where it expects a user, and the extra keys
		 * are sent back on save as fields the schema does not recognise.
		 *
		 * Added in 1.3.0 after the editor was found to be unusable for every
		 * mapped post type. The larger cause was REDI Headless CMS rewriting
		 * the same responses for every context, but this plugin was making its
		 * own contribution and is fixed here on its own merits: it should
		 * never have been touching edit responses.
		 */
		if ( $request instanceof WP_REST_Request && 'edit' === $request->get_param( 'context' ) ) {
			return $response;
		}

		$data = $response->get_data();
		if ( ! is_array( $data ) ) {
			return $response;
		}

		// REDI Headless CMS fills `author` from the WordPress user, which is the
		// account that happened to publish the row. Override it when a byline
		// has been set, and leave it untouched when it hasn't.
		$byline = get_field( 'authorName', $post->ID );
		if ( is_string( $byline ) && '' !== $byline ) {
			$data['author'] = array( 'name' => $byline );
		}

		$external = get_field( 'externalUrl', $post->ID );
		$data['externalUrl'] = is_string( $external ) && '' !== $external ? $external : null;

		$source = get_field( 'source', $post->ID );
		$data['source'] = ( is_array( $source ) && ! empty( $source['url'] ) )
			? array(
				'name' => isset( $source['name'] ) ? (string) $source['name'] : '',
				'url'  => (string) $source['url'],
			)
			: null;

		$data['heroImage'] = redi_post_fields_image( get_field( 'heroImage', $post->ID ) );

		$response->set_data( $data );
		return $response;
	},
	99,
	3
);

// ---------------------------------------------------------------------------
// 3. Stop WordPress rewriting punctuation in API responses.
// ---------------------------------------------------------------------------

/**
 * `wptexturize` is WordPress's smart-punctuation pass: it turns a hyphen
 * surrounded by spaces into an en dash and straight quotes into curly ones.
 * That silently rewrites approved copy — this site had em and en dashes
 * deliberately removed from visible content — so a title stored as
 * "Fair Oaks Industrial Park - Partner Tulsa" was being served with a dash
 * nobody chose.
 *
 * Removed only for REST requests, so the admin editor and anything rendering
 * through PHP keep WordPress's normal behaviour. `wpautop` is deliberately
 * left in place: it is what turns an editor's plain paragraphs into HTML, and
 * dropping it would break content written in wp-admin rather than imported.
 */
add_action(
	'rest_api_init',
	function () {
		remove_filter( 'the_title', 'wptexturize' );
		remove_filter( 'the_content', 'wptexturize' );
		remove_filter( 'the_excerpt', 'wptexturize' );
		remove_filter( 'comment_text', 'wptexturize' );
	}
);
