<?php
/**
 * Plugin Name:       REDI Admin Editor Fix
 * Description:       Restores the standard WordPress REST shape for wp-admin, so posts, team members, testimonials, partners and properties can be created and edited again. The frontend keeps the REDI shape exactly as before.
 * Version:           1.0.0
 * Author:            Ethixweb
 * Requires at least: 6.0
 * Requires PHP:      7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * What was broken
 * ---------------
 * REDI Headless CMS rewrites the REST response for the five custom types into
 * the shape the Astro frontend wants: `id` becomes the slug, `title` becomes a
 * plain string, and the core fields the frontend has no use for are dropped.
 *
 * That rewrite was applied to EVERY request, including the ones wp-admin makes
 * about itself. The block editor talks to the same `/wp/v2/<type>` routes and
 * needs WordPress's own shape back:
 *
 *   id        integer post ID, not a slug
 *   title     { raw, rendered }, not a string
 *   content   { raw, rendered } — the editor loads the body from `raw`
 *   status    draft / publish, so the editor knows what it is looking at
 *   type      the post type
 *   link, modified, date_gmt, and the rest of the standard envelope
 *
 * With `id` arriving as a string and `content`/`status`/`type` missing, the
 * editor cannot match the record it asked for. Opening an existing item gave
 * "You attempted to edit an item that doesn't exist. Perhaps it was deleted?"
 * even though the item was published and served fine over the API, and
 * creating a new one failed on the first autosave.
 *
 * Confirmed live on 2026-10-30 against every registered type:
 *
 *   post, team_member, testimonial, partner, property   rewritten, editor broken
 *   page                                                untouched, editor fine
 *
 * That split is the tell: Pages are the only type REDI Headless CMS does not
 * map, and Pages were the only type that still worked in wp-admin.
 *
 * How this fixes it
 * -----------------
 * REST requests carry a `context`. wp-admin and the block editor ask for
 * `context=edit`; the frontend uses the default, `view`. So the two audiences
 * are already distinguishable and nothing has to guess.
 *
 * This records WordPress's own response before anything rewrites it, then puts
 * it back for `context=edit` only. The frontend's `context=view` requests are
 * not touched at all and keep the REDI shape byte for byte.
 *
 * Deliberately not done here: editing REDI Headless CMS. It stays the owner of
 * the frontend shape. This sits beside it and is additive — deactivating this
 * plugin restores exactly the behaviour that exists today, broken editor
 * included.
 */

/** The types REDI Headless CMS rewrites. Pages are absent because it leaves them alone. */
function redi_admin_fix_post_types() {
	return array( 'post', 'team_member', 'testimonial', 'partner', 'property' );
}

/**
 * Stash of untouched responses for this request, keyed by post ID.
 *
 * Per-request only: REST serves one request per PHP process, and holding the
 * data in a static keeps it out of the options table and out of any cache.
 */
function &redi_admin_fix_store() {
	static $original = array();
	return $original;
}

add_action(
	'rest_api_init',
	function () {
		foreach ( redi_admin_fix_post_types() as $type ) {
			/*
			 * PHP_INT_MIN: ahead of REDI Headless CMS and of REDI Post Fields
			 * (which runs at 99), so what is captured here is WordPress's own
			 * output before any rewriting. Deliberately not priority 0 — that
			 * only wins against the default 10, and this has to hold even if
			 * another plugin also tries to go early.
			 */
			add_filter(
				"rest_prepare_{$type}",
				function ( $response, $post ) {
					if ( $response instanceof WP_REST_Response ) {
						$store              = &redi_admin_fix_store();
						$store[ $post->ID ] = $response->get_data();
					}
					return $response;
				},
				PHP_INT_MIN,
				2
			);

			/*
			 * Priority 9999: after every rewrite has run, so this is the last
			 * word for editor requests.
			 */
			add_filter(
				"rest_prepare_{$type}",
				function ( $response, $post, $request ) {
					if ( ! ( $response instanceof WP_REST_Response ) ) {
						return $response;
					}

					// Only wp-admin asks for `edit`. Leave `view` alone: that is
					// the frontend, and it must keep the REDI shape.
					if ( ! ( $request instanceof WP_REST_Request ) || 'edit' !== $request->get_param( 'context' ) ) {
						return $response;
					}

					$store = &redi_admin_fix_store();
					if ( ! isset( $store[ $post->ID ] ) || ! is_array( $store[ $post->ID ] ) ) {
						return $response; // Nothing captured; better to change nothing.
					}

					$original = $store[ $post->ID ];
					$current  = $response->get_data();

					/*
					 * Restore WordPress's shape, then keep any key the later
					 * filters added that WordPress did not have — REDI Post
					 * Fields' externalUrl, source and heroImage, for instance.
					 * A plain overwrite would drop those; this only reclaims
					 * the core keys the editor needs and leaves additions be.
					 */
					if ( is_array( $current ) ) {
						foreach ( $current as $key => $value ) {
							if ( ! array_key_exists( $key, $original ) ) {
								$original[ $key ] = $value;
							}
						}
					}

					$response->set_data( $original );
					return $response;
				},
				9999,
				3
			);
		}
	}
);
